========== USERS ==========
admin / admin123 (not implemented)
manager / manager123
storekeeper / storekeeper123
